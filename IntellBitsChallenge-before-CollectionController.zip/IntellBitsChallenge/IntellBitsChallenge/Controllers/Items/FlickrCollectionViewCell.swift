//
//  FlickrCollectionViewCell.swift
//  IntellBitsChallenge
//
//  Created by Julio Rico on 21/10/22.
//

import UIKit

class FlickrCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageContainer: UIImageView!
}
