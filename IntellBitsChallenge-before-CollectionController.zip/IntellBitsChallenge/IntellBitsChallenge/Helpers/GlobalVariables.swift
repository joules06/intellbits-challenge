//
//  GlobalVariables.swift
//  IntellBitsChallenge
//
//  Created by Julio Rico on 21/10/22.
//

import Foundation

enum K {
    static let FLICKR_API_IMAGE_PREFIX = "https://www.flickr.com/services/rest/"
}
