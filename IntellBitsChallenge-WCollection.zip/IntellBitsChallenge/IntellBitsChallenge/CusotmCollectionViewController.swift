//
//  CusotmCollectionViewController.swift
//  IntellBitsChallenge
//
//  Created by Julio Rico on 20/10/22.
//

import UIKit

private let reuseIdentifier = "CollectionCell"

struct CellViewModel {
    let title: String
    let boddy: String
}

class CusotmCollectionViewController: UICollectionViewController {
    private let data: [CellViewModel] = [
        CellViewModel(title: "1", boddy: "Uno..."),
        CellViewModel(title: "2", boddy: "Dos..."),
        CellViewModel(title: "3", boddy: "Tres..."),
        CellViewModel(title: "14", boddy: "Catorce..."),
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
//
//        self.collectionView!.register(MyCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        // Do any additional setup after loading the view.
    }

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        data.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! MyCell
        cell.configure(with: data[indexPath.row])

        
        // Configure the cell
    
        return cell
    }

}

class MyCell: UICollectionViewCell {
    @IBOutlet weak var firstLabel: UILabel!
    @IBOutlet weak var secondLabel: UILabel!
    
    
    func configure(with model: CellViewModel) {
        firstLabel.text = model.title
        secondLabel.text = model.boddy
    }
}
